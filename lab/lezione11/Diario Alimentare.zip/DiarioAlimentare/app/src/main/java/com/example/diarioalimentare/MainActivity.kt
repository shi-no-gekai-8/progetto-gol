package com.example.diarioalimentare

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.diarioalimentare.ui.PastoViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: PastoViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MaterialTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    DiarioScreen(
                        innerPadding = innerPadding,
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}

@Composable
fun DiarioScreen(
    innerPadding: PaddingValues,
    viewModel: PastoViewModel
) {
    val pasti by viewModel.pasti.collectAsState()

    var nome by remember { mutableStateOf("") }
    var calorie by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(
            value = nome,
            onValueChange = { nome = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Nome pasto") }
        )

        OutlinedTextField(
            value = calorie,
            onValueChange = { calorie = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Calorie") }
        )

        Button(
            onClick = {
                val calorieInt = calorie.toIntOrNull()
                if (nome.isNotBlank() && calorieInt != null) {
                    viewModel.inserisciPasto(nome, calorieInt)
                    nome = ""
                    calorie = ""
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Aggiungi pasto")
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(pasti) { pasto ->
                Row(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("${pasto.nome} - ${pasto.calorie} kcal")
                }
            }
        }
    }
}