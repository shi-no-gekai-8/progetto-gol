package com.example.saferide

import android.Manifest
import android.annotation.SuppressLint
import android.app.Application
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.saferide.data.SafeRideDatabase
import com.example.saferide.data.Viaggio
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/*
    Il ViewModel è il "cervello" della schermata.

    Lo usiamo per conservare i dati anche quando la Activity viene ricreata,
    ad esempio quando ruotiamo lo schermo.

    In questa Fase 1 prepariamo:
    - GPS
    - accelerometro
    - database Room
    - stato base della demo
*/
class SafeRideViewModel(
    application: Application
) : AndroidViewModel(application), SensorEventListener {

    private val appContext = application.applicationContext

    /*
        Client GPS moderno di Google Play Services.

        Lo useremo per ricevere aggiornamenti della posizione.
        Dalla Location possiamo leggere anche la velocità in metri al secondo.
    */
    private val fusedLocationClient =
        LocationServices.getFusedLocationProviderClient(appContext)

    /*
        SensorManager permette di accedere ai sensori fisici del telefono,
        per esempio accelerometro, giroscopio, sensore di luce, ecc.
    */
    private val sensorManager =
        appContext.getSystemService(SensorManager::class.java)

    /*
        Accelerometro del telefono.

        Può essere null su dispositivi molto particolari,
        quindi controlliamo sempre se esiste.
    */
    private val accelerometro: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    /*
        Database locale Room.
        In Fase 1 lo inizializziamo soltanto.
    */
    private val database = SafeRideDatabase.getDatabase(appContext)
    private val viaggioDao = database.viaggioDao()

    /*
        Stato della velocità corrente.

        MutableStateFlow:
        - è modificabile dal ViewModel
        - la UI può osservarlo e ridisegnarsi quando cambia

        La Location Android restituisce la velocità in metri al secondo.
    */
    private val _velocitaMetriSecondo = MutableStateFlow(0f)
    val velocitaMetriSecondo: StateFlow<Float> = _velocitaMetriSecondo.asStateFlow()

    /*
        Contatore base per le frenate brusche.

        In Fase 1 NON implementiamo ancora la logica vera.
        La Task 2 degli studenti servirà proprio a completarla.
    */
    private val _frenateBrusche = MutableStateFlow(0)
    val frenateBrusche: StateFlow<Int> = _frenateBrusche.asStateFlow()

    /*
        Messaggio didattico mostrato nella UI.

        È utile per far capire agli studenti cosa sta succedendo.
    */
    private val _messaggioStato = MutableStateFlow(
        "Demo pronta. Concedi il permesso GPS per iniziare."
    )
    val messaggioStato: StateFlow<String> = _messaggioStato.asStateFlow()

    /*
        Lista dei viaggi nel database.

        Per ora sarà vuota, ma serve per collegare la schermata Storico
        alla struttura Room.
    */
    val viaggi = viaggioDao.osservaTuttiIViaggi()

    /*
        Callback chiamata ogni volta che arriva una nuova posizione GPS.
    */
    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val ultimaPosizione = result.lastLocation ?: return

            /*
                Android ci dà la velocità in metri al secondo.

                NON la convertiamo qui in km/h per lasciare visibile
                agli studenti il dato originale del sistema.
                La conversione sarà parte della Task 1.
            */
            _velocitaMetriSecondo.value = ultimaPosizione.speed

            _messaggioStato.value =
                "GPS attivo. Velocità letta correttamente dal dispositivo."
        }
    }

    /*
        Controlla se abbiamo il permesso GPS.

        Questa funzione evita errori di sicurezza quando proviamo
        ad accedere alla posizione.
    */
    fun haPermessoGps(): Boolean {
        val permesso = ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.ACCESS_FINE_LOCATION
        )

        return permesso == PackageManager.PERMISSION_GRANTED
    }

    /*
        Avvia il motore della demo:
        - aggiornamenti GPS
        - ascolto dell'accelerometro

        Questa funzione viene chiamata dalla UI solo dopo aver ottenuto
        il permesso di posizione.
    */
    @SuppressLint("MissingPermission")
    fun avviaDemo() {
        if (!haPermessoGps()) {
            _messaggioStato.value =
                "Permesso GPS mancante. Premi il pulsante per richiederlo."
            return
        }

        avviaGps()
        avviaAccelerometro()

        _messaggioStato.value =
            "Demo avviata: GPS e accelerometro sono in ascolto."
    }

    @SuppressLint("MissingPermission")
    private fun avviaGps() {
        /*
            LocationRequest definisce ogni quanto vogliamo ricevere
            aggiornamenti della posizione.

            PRIORITY_HIGH_ACCURACY usa il GPS quando disponibile.
            Va bene per una demo di guida, ma consuma più batteria.
        */
        val richiestaPosizione = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY,
            1000L
        )
            .setMinUpdateIntervalMillis(500L)
            .build()

        fusedLocationClient.requestLocationUpdates(
            richiestaPosizione,
            locationCallback,
            null
        )
    }

    private fun avviaAccelerometro() {
        if (accelerometro == null) {
            _messaggioStato.value =
                "Accelerometro non disponibile su questo dispositivo."
            return
        }

        /*
            Registriamo questo ViewModel come ascoltatore del sensore.

            SENSOR_DELAY_NORMAL è sufficiente per una demo.
            Nelle Task gli studenti potranno ragionare su frequenze diverse.
        */
        sensorManager.registerListener(
            this,
            accelerometro,
            SensorManager.SENSOR_DELAY_NORMAL
        )
    }

    /*
        Questa funzione viene chiamata automaticamente quando il sensore
        produce un nuovo valore.
    */
    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        /*
            event.values contiene i valori dell'accelerometro:

            values[0] = asse X
            values[1] = asse Y
            values[2] = asse Z

            In Fase 1 NON rileviamo ancora la frenata brusca.
            Lasciamo solo il punto in cui gli studenti lavoreranno.
        */
        val accelerazioneY = event.values[1]

        /*
            Per ora scriviamo solo un messaggio quando arrivano dati.

            Nella Task 2 gli studenti confronteranno il valore attuale
            con quello precedente per calcolare il Delta.
        */
        _messaggioStato.value =
            "Accelerometro attivo. Asse Y letto: $accelerazioneY"
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        /*
            Per questa demo non ci serve gestire il cambio di accuratezza.
            La funzione però è obbligatoria perché usiamo SensorEventListener.
        */
    }

    /*
        Funzione dimostrativa per inserire un viaggio finto.

        Serve solo a verificare che Room funzioni e che la schermata
        Storico possa mostrare qualcosa.

        NON è il salvataggio reale del viaggio finale.
    */
    fun inserisciViaggioDemo() {
        viewModelScope.launch {
            val viaggioDemo = Viaggio(
                durataSecondi = 120,
                velocitaMassimaKmh = 42f,
                numeroFrenateBrusche = 0
            )

            viaggioDao.inserisciViaggio(viaggioDemo)

            _messaggioStato.value =
                "Viaggio demo inserito nel database Room."
        }
    }

    /*
        Quando il ViewModel viene distrutto, fermiamo GPS e sensori.

        È importante liberare le risorse per non consumare batteria
        e non lasciare sensori attivi inutilmente.
    */
    override fun onCleared() {
        super.onCleared()

        fusedLocationClient.removeLocationUpdates(locationCallback)
        sensorManager.unregisterListener(this)
    }
}