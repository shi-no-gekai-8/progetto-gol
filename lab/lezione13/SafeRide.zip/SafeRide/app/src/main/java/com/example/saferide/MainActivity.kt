package com.example.saferide

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.saferide.data.Viaggio
import kotlinx.coroutines.flow.Flow
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    /*
        Creiamo il ViewModel a livello di Activity.

        Così Dashboard e Storico possono usare lo stesso ViewModel
        e gli stessi dati.
    */
    private val viewModel: SafeRideViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            SafeRideApp(viewModel = viewModel)
        }
    }
}

@Composable
fun SafeRideApp(viewModel: SafeRideViewModel) {
    /*
        NavController gestisce gli spostamenti tra schermate.

        Per questa Fase 1 abbiamo solo:
        - dashboard
        - storico
    */
    val navController = rememberNavController()

    MaterialTheme {
        Surface(
            modifier = androidx.compose.ui.Modifier.fillMaxSize()
        ) {
            Scaffold(
                bottomBar = {
                    SafeRideBottomBar(navController = navController)
                }
            ) { paddingValues ->

                NavHost(
                    navController = navController,
                    startDestination = "dashboard",
                    modifier = androidx.compose.ui.Modifier.padding(paddingValues)
                ) {
                    composable("dashboard") {
                        DashboardScreen(viewModel = viewModel)
                    }

                    composable("storico") {
                        StoricoScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun SafeRideBottomBar(navController: NavController) {
    /*
        Leggiamo la schermata corrente per evidenziare
        il pulsante giusto nella barra in basso.
    */
    val backStackEntry by navController.currentBackStackEntryAsState()
    val routeCorrente = backStackEntry?.destination?.route

    NavigationBar {
        NavigationBarItem(
            selected = routeCorrente == "dashboard",
            onClick = {
                navController.navigate("dashboard") {
                    launchSingleTop = true
                }
            },
            label = {
                Text("Dashboard")
            },
            icon = {
                Text("🚗")
            }
        )

        NavigationBarItem(
            selected = routeCorrente == "storico",
            onClick = {
                navController.navigate("storico") {
                    launchSingleTop = true
                }
            },
            label = {
                Text("Storico")
            },
            icon = {
                Text("📋")
            }
        )
    }
}

@Composable
fun DashboardScreen(viewModel: SafeRideViewModel) {
    /*
        collectAsStateWithLifecycle osserva i dati del ViewModel
        rispettando il ciclo di vita della schermata.

        Quando il valore cambia, Compose ridisegna automaticamente
        la parte interessata della UI.
    */
    val velocitaMs by viewModel.velocitaMetriSecondo.collectAsStateWithLifecycle()
    val frenateBrusche by viewModel.frenateBrusche.collectAsStateWithLifecycle()
    val messaggioStato by viewModel.messaggioStato.collectAsStateWithLifecycle()

    /*
        Launcher per chiedere il permesso GPS.

        Quando l'utente risponde alla finestra di permesso,
        il risultato arriva dentro la lambda.
    */
    val launcherPermessoGps = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { permessoConcesso ->
        if (permessoConcesso) {
            viewModel.avviaDemo()
        }
    }

    Column(
        modifier = androidx.compose.ui.Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "SafeRide - Dashboard",
            style = MaterialTheme.typography.headlineMedium
        )

        Card(
            modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = androidx.compose.ui.Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Istruzioni per usare la demo",
                    style = MaterialTheme.typography.titleMedium
                )

                Spacer(modifier = androidx.compose.ui.Modifier.height(8.dp))

                Text(
                    text = """
                    1. Premi “Avvia demo”.
                    2. Concedi il permesso GPS.
                    3. Muovi il telefono o usa l’emulatore con posizione simulata.
                    4. Guarda i dati grezzi letti da GPS e accelerometro.
                    5. Vai nello Storico per vedere la struttura Room.
                    """.trimIndent()
                )
            }
        }

        Card(
            modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = androidx.compose.ui.Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Dati live grezzi",
                    style = MaterialTheme.typography.titleMedium
                )

                Spacer(modifier = androidx.compose.ui.Modifier.height(8.dp))

                /*
                    In Fase 1 mostriamo la velocità così come arriva da Android:
                    metri al secondo.

                    La conversione in km/h sarà una Task degli studenti.
                */
                Text(text = "Velocità GPS: $velocitaMs m/s")

                /*
                    In Fase 1 il contatore resta a zero.
                    Gli studenti lo completeranno nella Task 2.
                */
                Text(text = "Frenate brusche: $frenateBrusche")

                Spacer(modifier = androidx.compose.ui.Modifier.height(8.dp))

                Text(text = "Stato: $messaggioStato")
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = {
                    if (viewModel.haPermessoGps()) {
                        viewModel.avviaDemo()
                    } else {
                        launcherPermessoGps.launch(
                            Manifest.permission.ACCESS_FINE_LOCATION
                        )
                    }
                }
            ) {
                Text("Avvia demo")
            }

            Button(
                onClick = {
                    viewModel.inserisciViaggioDemo()
                }
            ) {
                Text("Inserisci viaggio demo")
            }
        }

        Card(
            modifier = androidx.compose.ui.Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = androidx.compose.ui.Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Cosa NON è ancora implementato",
                    style = MaterialTheme.typography.titleMedium
                )

                Spacer(modifier = androidx.compose.ui.Modifier.height(8.dp))

                Text(
                    text = """
                    - Tachimetro colorato.
                    - Conversione visiva in km/h.
                    - Rilevamento reale della frenata brusca.
                    - Salvataggio automatico del viaggio finale.
                    
                    Queste parti saranno completate dagli studenti nella Fase 2.
                    """.trimIndent()
                )
            }
        }
    }
}

@Composable
fun StoricoScreen(viewModel: SafeRideViewModel) {
    /*
        Qui osserviamo i viaggi dal database Room.

        collectAsState è sufficiente per la demo.
        In progetti più grandi si può usare collectAsStateWithLifecycle
        anche per Flow provenienti dal database.
    */
    val viaggi by viewModel.viaggi.collectAsState(initial = emptyList())

    Column(
        modifier = androidx.compose.ui.Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        Text(
            text = "Storico Viaggi",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = androidx.compose.ui.Modifier.height(16.dp))

        Text(
            text = "Questa schermata mostra i dati letti dal database locale Room."
        )

        Spacer(modifier = androidx.compose.ui.Modifier.height(16.dp))

        if (viaggi.isEmpty()) {
            Text(
                text = """
                Nessun viaggio salvato.
                
                Torna nella Dashboard e premi “Inserisci viaggio demo”
                per verificare che Room funzioni.
                """.trimIndent()
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(viaggi) { viaggio ->
                    ViaggioCard(viaggio = viaggio)
                }
            }
        }
    }
}

@Composable
fun ViaggioCard(viaggio: Viaggio) {
    Card(
        modifier = androidx.compose.ui.Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = androidx.compose.ui.Modifier.padding(16.dp)
        ) {
            Text(
                text = "Viaggio #${viaggio.id}",
                style = MaterialTheme.typography.titleMedium
            )

            Text(text = "Durata: ${viaggio.durataSecondi} secondi")
            Text(text = "Velocità massima: ${viaggio.velocitaMassimaKmh} km/h")
            Text(text = "Frenate brusche: ${viaggio.numeroFrenateBrusche}")
        }
    }
}