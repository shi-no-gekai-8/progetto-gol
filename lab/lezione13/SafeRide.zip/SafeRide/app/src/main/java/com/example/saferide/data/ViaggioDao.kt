package com.example.saferide.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/*
    DAO significa Data Access Object.

    È l'interfaccia attraverso cui parliamo con il database.
    Noi scriviamo solo le funzioni: Room genererà il codice vero.
*/
@Dao
interface ViaggioDao {

    /*
        Inserisce un nuovo viaggio nel database.

        Questa funzione è "suspend" perché il database non va usato
        sul thread principale della UI.
    */
    @Insert
    suspend fun inserisciViaggio(viaggio: Viaggio)

    /*
        Restituisce tutti i viaggi ordinati dal più recente al più vecchio.

        Flow significa: "osserva questi dati".
        Se il database cambia, la UI può aggiornarsi automaticamente.
    */
    @Query("SELECT * FROM viaggi ORDER BY timestamp DESC")
    fun osservaTuttiIViaggi(): Flow<List<Viaggio>>
}