package com.example.saferide.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/*
    Questa classe rappresenta una tabella del database.

    Ogni oggetto Viaggio sarà una riga nella tabella "viaggi".

    Per ora creiamo solo la struttura.
    Nella Fase 1 NON salviamo ancora viaggi reali.
*/
@Entity(tableName = "viaggi")
data class Viaggio(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    // Durata del viaggio in secondi.
    val durataSecondi: Long,

    // Velocità massima raggiunta durante il viaggio, in km/h.
    val velocitaMassimaKmh: Float,

    // Numero di frenate brusche rilevate durante il viaggio.
    val numeroFrenateBrusche: Int,

    // Data di creazione del viaggio.
    val timestamp: Long = System.currentTimeMillis()
)