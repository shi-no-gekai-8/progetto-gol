package com.example.saferide.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/*
    Questa è la classe principale del database Room.

    Qui diciamo:
    - quali Entity esistono
    - quale versione ha il database
    - quali DAO possiamo usare
*/
@Database(
    entities = [Viaggio::class],
    version = 1
)
abstract class SafeRideDatabase : RoomDatabase() {

    abstract fun viaggioDao(): ViaggioDao

    companion object {

        /*
            INSTANCE conterrà l'unica copia del database.

            Usiamo una sola istanza perché aprire tanti database diversi
            nella stessa app può creare problemi e sprechi di memoria.
        */
        @Volatile
        private var INSTANCE: SafeRideDatabase? = null

        fun getDatabase(context: Context): SafeRideDatabase {
            return INSTANCE ?: synchronized(this) {
                val nuovaIstanza = Room.databaseBuilder(
                    context.applicationContext,
                    SafeRideDatabase::class.java,
                    "saferide_database"
                ).build()

                INSTANCE = nuovaIstanza
                nuovaIstanza
            }
        }
    }
}