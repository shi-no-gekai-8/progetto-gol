package com.example.laboratorio5

import android.Manifest
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOff
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    // Client Google per ottenere la posizione
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    // Gestore del DataStore
    private lateinit var stepDataStore: StepDataStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Inizializziamo il client GPS
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Inizializziamo il DataStore
        stepDataStore = StepDataStore(this)

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    GPSPedometerApp(
                        fusedLocationClient = fusedLocationClient,
                        stepDataStore = stepDataStore
                    )
                }
            }
        }
    }
}

@Composable
fun GPSPedometerApp(
    fusedLocationClient: FusedLocationProviderClient,
    stepDataStore: StepDataStore
) {
    val context = LocalContext.current

    // Stato del permesso GPS
    var hasLocationPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    // Ultima posizione nota
    var lastKnownLocation by remember { mutableStateOf<Location?>(null) }

    // Valore salvato nel DataStore
    val savedSteps by stepDataStore.totalStepsFlow.collectAsState(initial = 0)

    // Launcher moderno per chiedere il permesso
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasLocationPermission = isGranted
    }

    // Quando il permesso cambia, proviamo a leggere l'ultima posizione
    LaunchedEffect(hasLocationPermission) {
        if (hasLocationPermission) {
            try {
                fusedLocationClient.lastLocation
                    .addOnSuccessListener { location: Location? ->
                        lastKnownLocation = location
                    }
            } catch (e: SecurityException) {
                e.printStackTrace()
            }
        }
    }

    if (hasLocationPermission) {
        PermissionGrantedScreen(
            location = lastKnownLocation,
            savedSteps = savedSteps,
            onFakeSaveExample = {
                (context as? ComponentActivity)?.lifecycleScope?.launch {
                    stepDataStore.saveSteps(savedSteps + 100)
                }
            }
        )
    } else {
        PermissionDeniedScreen(
            onRequestPermission = {
                permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        )
    }
}

@Composable
fun PermissionDeniedScreen(
    onRequestPermission: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.LocationOff,
            contentDescription = "GPS non disponibile",
            modifier = Modifier.size(72.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Devi abilitare il GPS per usare l'app!",
            style = MaterialTheme.typography.headlineSmall,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "In questa fase stiamo costruendo solo lo scaffolding: senza permesso non possiamo leggere la posizione.",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(onClick = onRequestPermission) {
            Text("Concedi permesso")
        }
    }
}

@Composable
fun PermissionGrantedScreen(
    location: Location?,
    savedSteps: Int,
    onFakeSaveExample: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {

            Icon(
                imageVector = Icons.Default.MyLocation,
                contentDescription = "GPS attivo",
                modifier = Modifier.size(72.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Permesso GPS concesso ✅",
                style = MaterialTheme.typography.headlineSmall
            )

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Passi salvati nel DataStore: $savedSteps",
                style = MaterialTheme.typography.bodyLarge
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (location != null) {
                Text(
                    text = "Latitudine: ${location.latitude}",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = "Longitudine: ${location.longitude}",
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                Text(
                    text = "Nessuna posizione disponibile al momento.\nSull'emulatore devi simulare una location.",
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(onClick = onFakeSaveExample) {
                Text("Salva +100 passi (demo)")
            }
        }
    }
}